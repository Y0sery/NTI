import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { MySrv } from '../services/posts.services';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

@Component({
 selector: 'app-post-create',
 standalone: true,
 imports: [CommonModule,ReactiveFormsModule,HttpClientModule],
 templateUrl: './postcreate.component.html',
 styleUrls: ['./postcreate.component.scss'],
 providers:[MySrv]
})
export class PostCreateComponent {
 anyThing:any; x:number=0; y:any=[];
 f: FormGroup;

 constructor(private s: MySrv) {
  this.f = new FormGroup({
   title: new FormControl('', [Validators.required]),
   body: new FormControl('', [Validators.required]),
  });
 }

 onSubmit() {
  if (this.f.valid) {
   this.s.createPost(this.f.value).subscribe(() => {
    alert('Post created successfully!');
    this.f.reset();
   });
  }
 }
}
