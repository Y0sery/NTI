import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { MySrv } from '../services/posts.services';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

@Component({
 selector: 'app-post-update',
 standalone: true,
 imports: [CommonModule,ReactiveFormsModule,RouterModule,HttpClientModule],
 templateUrl: './postupdate.component.html',
 styleUrls: ['./postupdate.component.scss'],
 providers:[MySrv]
})
export class PostUpdateComponent implements OnInit {
 anyThing:any; x:number=0; y:any=[];
 f: FormGroup;
 postId: number =0;

 constructor(private postsService: MySrv, private route: ActivatedRoute) {
  this.f = new FormGroup({
   title: new FormControl('', [Validators.required]),
   body: new FormControl('', [Validators.required]),
  });
 }

 ngOnInit(): void {
  
  this.route.params.subscribe((params) => {
   this.postId = +params['id'];
   this.getPost(this.postId);
  });

 }

 getPost(id: number) {
  this.s.getPost(id).subscribe((data) => {
   console.log(data);
   
   this.f.patchValue({
    title: data.title,
    body: data.body,
   });

  });
 }

 onSubmit() {
  if (this.f.valid) {
   this.s.updatePost(this.postId, this.f.value).subscribe(() => {
    alert('Post updated successfully!');
   });
  }
 }
}
